<?php 
//il sagit la d'un bout du menu mis dans un echo, qui pourra servir si besoins est via include ou require
     echo '<!--********Début de mon menu*********-->
<header><!--Début menu guauche-->
 <div id="menu_G">
  <ul>
   <li class="deroulant"><a href="index.php">Accueil</a></li>
  </ul> 
 </div>
 <h1>RIDE NOW</h1>
<!--Le menu guache contient le bouton renvoyant à la page d accueil.-->

<!--Le menu droit contient un lien vers un F.A.Q.-->
<div id="menu_D">
  <ul>
    <li><a href="https://www.instagram.com/zampakuto/" target="blank" class="instaLogo"><img src="images/insta.png" width="70px" alt="logo_instagram"></a></li><!--Lien menant à un compte instagram dédié.-->
  </ul>  
</div>
<!--Fin de mon menu_D-->
</header>
<!--**********Fin de mon (MENU)**********-->';

 ?>