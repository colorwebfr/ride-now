<?php 
//Liste à puce qui n'est pas utiliuser mais qui peut servir si besoin de sous categorie dans le menu sous forme de liste déroulantes via css.
     echo '<nav>
  <ul>
    <li class="deroulant"><a href="#">Skate</a>
       <ul class="sous">
         <li><a href="#">Planches</a><hr></li>
         <li><a href="#">Trucks</a><hr></li>
         <li><a href="#">Roues</a><hr></li>
         <li><a href="#">Autres</a></li>
       </ul>
    </li>
  </ul>
  <ul>  
    <li class="deroulant"><a href="#">Surf</a>
       <ul class="sous">
         <li><a href="#">Planches</a><hr></li>
         <li><a href="#">Combinaisons</a><hr></li>
         <li><a href="#">Derives</a><hr></li>
         <li><a href="#">Housses</a><hr></li>
         <li><a href="#">Autres</a></li> 
       </ul>
    </li>
  </ul>
  <ul>
    <li class="deroulant"><a href="#">Paddle</a>
       <ul class="sous">
          <li><a href="#">Planches</a><hr></li>
          <li><a href="#">Combinaisons</a><hr></li>
          <li><a href="#">Pagaies</a><hr></li>
          <li><a href="#">Derives</a><hr></li>
          <li><a href="#">Housses</a><hr></li>
          <li><a href="#">Autres</a></li>
       </ul>
    </li>
  </ul>
  <ul>
    <li class="deroulant"><a href="#">Snowboard</a>
       <ul class="sous">
          <li><a href="#">Planches</a><hr></li>
          <li><a href="#">Fixations</a><hr></li>
          <li><a href="#">Chaussures</a><hr></li>
          <li><a href="#">Housses</a><hr></li>
          <li><a href="#">Autres</a></li>
       </ul>
    </li>
  </ul>
  </nav>  ';

 ?>